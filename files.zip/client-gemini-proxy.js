// Замените часть generateSafetyAdvice в HTML на следующий код (или подключите как внешний скрипт).

async function generateSafetyAdvice() {
    const scenarioInput = document.getElementById('safety-scenario');
    const resultsContainer = document.getElementById('advice-results');
    const generateButton = document.getElementById('generate-advice-btn');
    const query = scenarioInput.value.trim();

    if (!query) {
        resultsContainer.innerHTML = `<div class="text-red-600 font-semibold mt-2">Пожалуйста, опишите сценарий.</div>`;
        return;
    }

    generateButton.disabled = true;
    generateButton.setAttribute('aria-busy', 'true');
    generateButton.innerHTML = 'Загрузка...';
    resultsContainer.innerHTML = `<div class="text-center py-4 text-gray-500">Ищем советы от ведущих экспертов...</div>`;

    const systemPrompt = "Вы — 'Консультант по детской безопасности' BabyTag. Предоставьте родителям краткий, но действенный совет..."; // укоротил

    try {
        const resp = await fetch('/api/gemini', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ userQuery: `Родитель спрашивает: "${query}" - Дайте совет.`, systemPrompt })
        });

        if (!resp.ok) {
            const errText = await resp.text();
            throw new Error(errText || 'Server error');
        }

        const result = await resp.json();
        const candidate = result.candidates?.[0];
        const text = candidate?.content?.parts?.[0]?.text || 'Не удалось получить ответ. Попробуйте переформулировать запрос.';

        // Обработка источников, если они есть
        let sourcesHtml = '';
        const grounding = candidate?.groundingMetadata;
        if (grounding?.groundingAttributions) {
            const sources = grounding.groundingAttributions
              .map(a => ({ uri: a.web?.uri, title: a.web?.title }))
              .filter(s => s.uri && s.title);
            if (sources.length) {
                sourcesHtml = `<div class="mt-4 text-xs text-gray-500 border-t pt-2"><p class="font-semibold mb-1">Источники:</p><ul class="list-disc list-inside space-y-1">${sources.slice(0,3).map(s => `<li><a href="${s.uri}" target="_blank" class="text-babytag-gray-dark hover:underline">${s.title}</a></li>`).join('')}</ul></div>`;
            }
        }

        resultsContainer.innerHTML = `<div class="bg-babytag-gray-light p-4 rounded-xl border border-babytag-yellow/50 shadow-inner" aria-live="polite">
            <p class="text-babytag-gray-dark font-semibold">${text}</p>
            ${sourcesHtml}
        </div>`;
    } catch (err) {
        console.error('Ошибка запроса к бэкенду:', err);
        resultsContainer.innerHTML = `<div class="text-red-600 mt-2">Произошла ошибка при запросе к Консультанту. Попробуйте позже.</div>`;
    } finally {
        generateButton.disabled = false;
        generateButton.removeAttribute('aria-busy');
        generateButton.innerHTML = 'Получить совет от эксперта ✨';
    }
}