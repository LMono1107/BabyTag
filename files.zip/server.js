// server.js
// Простой прокси для вызова Google Generative Language API.
// Устанавливайте NODE_ENV=production и храните GOOGLE_API_KEY в .env

const express = require('express');
const fetch = require('node-fetch'); // npm i node-fetch@2 (или используйте глобальный fetch в Node 18+)
require('dotenv').config();

const app = express();
app.use(express.json());

const GOOGLE_API_KEY = process.env.GOOGLE_API_KEY;
if (!GOOGLE_API_KEY) {
  console.warn('GOOGLE_API_KEY is not set. Set it in .env');
}

const MODEL_ENDPOINT = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-09-2025:generateContent';

app.post('/api/gemini', async (req, res) => {
  try {
    const { userQuery, systemPrompt } = req.body;
    if (!userQuery) return res.status(400).json({ error: 'userQuery is required' });

    // Сформируйте payload по вашей текущей логике — проверьте актуальную документацию Google и приведите к ней
    const payload = {
      contents: [{ parts: [{ text: userQuery }] }],
      systemInstruction: { parts: [{ text: systemPrompt || '' }] },
      // Не добавляем tools с client-side именами; если нужна web search — используйте официальные интеграции Google и их docs.
    };

    const url = `${MODEL_ENDPOINT}?key=${GOOGLE_API_KEY}`;
    const r = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (!r.ok) {
      const text = await r.text();
      return res.status(r.status).json({ error: text });
    }

    const result = await r.json();
    // Можно фильтровать/логировать result для безопасности
    return res.json(result);
  } catch (err) {
    console.error('Error proxying to Gemini:', err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server listening on ${PORT}`));